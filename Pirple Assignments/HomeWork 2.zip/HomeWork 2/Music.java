/*The file is created by Rohith Samuel
Title - Metadata 
This Program Contains the music meta data of the song stone cold by demi lovato
*/


public class Music {
    public static void main(String[] args){
        
        String Artist = "Demi Lovato";
        String Album = "Confident";
        String Title = "Stone Cold";
        String Genre = "Pop";
        int year =  2017;
        int Trackno = 1;
        double duration = 4.05;
                
        System.out.println("Artist"+" "+Artist);
        System.out.println("Album"+" "+Album);
        System.out.println("Title"+" "+Title);
        System.out.println("Genre"+" "+Genre);
        System.out.println("Year"+" "+year);
        System.out.println("Track No"+" "+Trackno);
        System.out.println("Duration"+" "+duration);
        
        
    }




















            
    
}
